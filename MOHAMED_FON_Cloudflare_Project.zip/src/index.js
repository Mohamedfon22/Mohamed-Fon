const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store"}});
const clean=(v,n=2000)=>String(v??"").trim().slice(0,n);
const auth=(r,e)=>Boolean(e.ADMIN_PASSWORD&&(r.headers.get("x-admin-password")||"")===e.ADMIN_PASSWORD);
export default {async fetch(request,env){
 const u=new URL(request.url),p=u.pathname,m=request.method;
 if(p==="/api/products"&&m==="GET"){const {results}=await env.DB.prepare("SELECT id,name,description,price,image_url,category FROM products ORDER BY id DESC").all();return json(results);}
 if(p==="/api/products"&&m==="POST"){if(!auth(request,env))return json({error:"غير مصرح"},401);const b=await request.json(),name=clean(b.name,160);if(!name)return json({error:"اسم المنتج مطلوب"},400);const x=await env.DB.prepare("INSERT INTO products(name,description,price,image_url,category) VALUES(?,?,?,?,?)").bind(name,clean(b.description),Number(b.price)||0,clean(b.image_url,1500),clean(b.category,100)).run();return json({id:x.meta.last_row_id},201);}
 const pm=p.match(/^\/api\/products\/(\d+)$/);if(pm&&m==="DELETE"){if(!auth(request,env))return json({error:"غير مصرح"},401);await env.DB.prepare("DELETE FROM products WHERE id=?").bind(+pm[1]).run();return json({success:true});}
 if(p==="/api/orders"&&m==="POST"){const b=await request.json(),items=Array.isArray(b.items)?b.items.slice(0,50):[];if(!clean(b.name,160)||!clean(b.phone,40)||!items.length)return json({error:"أكمل بيانات العميل والسلة"},400);
 const c=await env.DB.prepare("INSERT INTO customers(name,phone,governorate,city,address) VALUES(?,?,?,?,?)").bind(clean(b.name,160),clean(b.phone,40),clean(b.governorate,100),clean(b.city,100),clean(b.address,500)).run();
 const total=items.reduce((s,i)=>s+Math.max(1,+i.quantity||1)*(+i.price||0),0),o=await env.DB.prepare("INSERT INTO orders(customer_id,total,notes) VALUES(?,?,?)").bind(c.meta.last_row_id,total,clean(b.notes,1000)).run();
 for(const i of items)await env.DB.prepare("INSERT INTO order_items(order_id,product_id,product_name,quantity,unit_price) VALUES(?,?,?,?,?)").bind(o.meta.last_row_id,+i.id||null,clean(i.name,160),Math.max(1,+i.quantity||1),+i.price||0).run();
 return json({success:true,order_id:o.meta.last_row_id,total},201);}
 if(p==="/api/maintenance"&&m==="POST"){const b=await request.json(),v=[clean(b.name,160),clean(b.phone,40),clean(b.device_type,120),clean(b.issue,2000)];if(v.some(x=>!x))return json({error:"يرجى إكمال جميع البيانات"},400);const x=await env.DB.prepare("INSERT INTO maintenance_requests(name,phone,device_type,issue) VALUES(?,?,?,?)").bind(...v).run();return json({success:true,request_id:x.meta.last_row_id},201);}
 if(p.startsWith("/api/admin/")){if(!auth(request,env))return json({error:"كلمة مرور الإدارة غير صحيحة"},401);
 if(p==="/api/admin/maintenance"&&m==="GET"){const {results}=await env.DB.prepare("SELECT * FROM maintenance_requests ORDER BY id DESC LIMIT 200").all();return json(results);}
 const mm=p.match(/^\/api\/admin\/maintenance\/(\d+)$/);if(mm&&m==="PATCH"){const b=await request.json(),allowed=["جديد","قيد الفحص","جاري الإصلاح","تم الإصلاح","تم التسليم"];if(!allowed.includes(b.status))return json({error:"حالة غير صحيحة"},400);await env.DB.prepare("UPDATE maintenance_requests SET status=? WHERE id=?").bind(b.status,+mm[1]).run();return json({success:true});}
 if(p==="/api/admin/orders"&&m==="GET"){const {results}=await env.DB.prepare("SELECT o.*,c.name,c.phone FROM orders o JOIN customers c ON c.id=o.customer_id ORDER BY o.id DESC LIMIT 200").all();return json(results);}}
 if(p.startsWith("/api/"))return json({error:"غير موجود"},404);
 return env.ASSETS.fetch(request);
}};
